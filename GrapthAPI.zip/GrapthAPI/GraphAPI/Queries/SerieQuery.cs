using System;
using System.Collections.Generic;
using System.Linq;
using GraphAPI.Models;


namespace GraphAPI.Queries
{
    public class SerieQuery
    {
        private List<Serie> series;

        public SerieQuery()
        {
            series = new List<Serie>
            {
               new Serie
                {
                    Id = 1,
                    Name = "One Piece",
                    ReleaseDate = DateTime.UtcNow.AddDays(-10),
                    Plataforms = new List<Plataform>
                    {
                        new Plataform
                        {
                            Name = "CrunchyRoll",
                            Followers = 1000
                        },
                        new Plataform
                        {
                            Name = "Netflix",
                            Followers = 2000
                        }
                    }
                },
                new Serie
                {
                    Id = 2,
                    Name = "Two Piece",
                    ReleaseDate = DateTime.UtcNow.AddDays(-20),
                    Plataforms = new List<Plataform>
                    {
                        new Plataform
                        {
                            Name = "CrunchyRoll",
                            Followers = 2000
                        }
                    }
                }
            };
        }
        
        public Serie GetSeriesById(int id)
            {
                return series.FirstOrDefault(s => s.Id == id);
            }
    }
}
