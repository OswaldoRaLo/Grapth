namespace GraphAPI.Models
{
    public class Plataform
    {
        public string Name { get; set; }
        public int Followers { get; set; }
    }
}
